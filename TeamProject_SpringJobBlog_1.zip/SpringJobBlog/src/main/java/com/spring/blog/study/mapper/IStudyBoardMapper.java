package com.spring.blog.study.mapper;

import java.util.List;

import com.spring.blog.command.ResumeBoardVO;
import com.spring.blog.command.StudyBoardVO;
import com.spring.blog.util.PageVO;

public interface IStudyBoardMapper {
	
	//글 등록
	void write(StudyBoardVO vo);
		
	//글 목록
	List<StudyBoardVO> getList(PageVO vo);
		
	//총 게시물 수
	int getTotal(PageVO vo);
	
	//조회수 상승 처리
	void updateViewCnt(int stuNo);

	//상세보기
	StudyBoardVO getDetail(int stuNo);
		
	//수정
	void update(StudyBoardVO vo);			
			
	//삭제
	void delete(StudyBoardVO vo);
}
