package com.spring.blog.comment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.blog.command.CommentVO;
import com.spring.blog.comment.mapper.ICommentMapper;

@Service
public class CommentService implements ICommentService {
	
	@Autowired
	private ICommentMapper mapper;

	@Override
	public List<CommentVO> scmtList(int stuNo) {
		return mapper.scmtList(stuNo);
	}

	@Override
	public List<CommentVO> fcmtList(int freeNo) {
		return mapper.fcmtList(freeNo);	}

	@Override
	public List<CommentVO> rcmtList(int resNo) {
		return mapper.rcmtList(resNo);
	}

	@Override
	public List<CommentVO> icmtList(int interNo) {
		return mapper.icmtList(interNo);
	}
	
	@Override
	public List<CommentVO> jcmtList(int jobNo) {
		return mapper.jcmtList(jobNo);
	}

	@Override
	public void cmtUpdate(CommentVO vo) {
		mapper.cmtUpdate(vo);

	}
	
	@Override
	public void cmtDelete(int cmtNo) {
		mapper.cmtDelete(cmtNo);

	}

	@Override
	public int scmtTotal(int stuNo) {
		return mapper.scmtTotal(stuNo);
	}

	@Override
	public int fcmtTotal(int freeNo) {
		return mapper.fcmtTotal(freeNo);
	}

	@Override
	public int rcmtTotal(int resNo) {
		return mapper.rcmtTotal(resNo);
	}

	@Override
	public int icmtTotal(int interNo) {
		return mapper.icmtTotal(interNo);
	}

	@Override
	public void scmtWrite(CommentVO vo) {
		mapper.scmtWrite(vo);
		
	}

	@Override
	public void fcmtWrite(CommentVO vo) {
		mapper.fcmtWrite(vo);
		
	}

	@Override
	public void rcmtWrite(CommentVO vo) {
		mapper.rcmtWrite(vo);
		
	}

	@Override
	public void icmtWrite(CommentVO vo) {
		mapper.icmtWrite(vo);
		
	}
	
	@Override
	public void jcmtWrite(CommentVO vo) {
		mapper.jcmtWrite(vo);
		
	}

	


}
