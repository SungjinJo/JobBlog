package com.spring.blog.command;

import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/*
CREATE TABLE user_table(
    u_id VARCHAR2(50) NOT NULL PRIMARY KEY,
    u_pw VARCHAR2(100) NOT NULL,
    u_board_hit NUMBER(30),
    u_pwconfirm VARCHAR2(100) NOT NULL,
    u_pwAnswer VARCHAR2(100) NOT NULL,
    u_nickname VARCHAR2(50) NOT NULL,
    u_name VARCHAR2(30) NOT NULL,
    u_email VARCHAR2(100) NOT NULL,
    u_phone VARCHAR2(100) NOT NULL,
    u_addrPost VARCHAR2(100) NOT NULL,
    u_addrBasic VARCHAR2(100) NOT NULL,
    u_addrDetail  VARCHAR2(100) NOT NULL,
    u_grade VARCHAR2(100) DEFAULT 1,
    u_crnumber VARCHAR2(100) DEFAULT NULL,
    regist_date DATE default SYSDATE,
    user_img VARCHAR2(100) DEFAULT '/image/basic.png'  
);
*/

@Getter
@Setter
@ToString
public class UserVO {
	
	private String userId;
	private String userPw;
	private String userPwConfirm;
	private String userPwAnswer;
	private String userNickname;
	private String userName;
	private String userEmail;
	private String userPhone;
	private String userAddrPost;
	private String userAddrBasic;
	private String userAddrDetail;
	private String userGrade;
	private String userCrnumber;
	private Timestamp registDate;
	private String userImg;
	private int userBoardHit;
	
}


