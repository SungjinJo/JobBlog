package com.spring.blog.job.mapper;

import java.util.List;

import com.spring.blog.command.CalendarVO;
import com.spring.blog.command.JobVO;
import com.spring.blog.util.PageVO;

public interface IJobMapper {

	//채용공고 목록
	List<JobVO> getList(PageVO vo);
	
	//채용공고 게시물 수 
	int getTotal(PageVO vo);
	
	//채용공고 등록
	void regist(JobVO vo);
	
	//채용공고 상세보기
	JobVO getDetail(int jobNo);
	
	//채용공고 수정하기
	void update(JobVO vo);
	
	//채용공고 삭제하기
	void delete(int jobNo);
	
	//채용공고 조회수
	void viewCount(int jobNo);
	
	//일정불러오기
	List<CalendarVO> getCalendar();

}
