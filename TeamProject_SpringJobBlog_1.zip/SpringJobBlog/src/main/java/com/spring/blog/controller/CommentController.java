package com.spring.blog.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.blog.command.CommentVO;
import com.spring.blog.comment.service.ICommentService;

@RestController
@RequestMapping("/comment")
public class CommentController {
	
	@Autowired
	private ICommentService service;
	
	
	@PostMapping("/scmtWrite/{stuNo}")
	public String scmtWrite(@RequestBody CommentVO vo) {
		System.out.println("댓글 등록요청 들어옴!");
		service.scmtWrite(vo);
		
		return "writeSuccess";	
	}
	
	@PostMapping("/fcmtWrite/{freeNo}")
	public String fcmtWrite(@RequestBody CommentVO vo) {
		System.out.println("댓글 등록요청 들어옴!");
		service.fcmtWrite(vo);
		
		return "writeSuccess";	
	}
	
	@PostMapping("/rcmtWrite/{resNo}")
	public String rcmtWrite(@RequestBody CommentVO vo) {
		System.out.println("댓글 등록요청 들어옴!");
		service.rcmtWrite(vo);
		
		return "writeSuccess";	
	}
	
	@PostMapping("/icmtWrite/{interNo}")
	public String icmtWrite(@RequestBody CommentVO vo) {
		System.out.println("댓글 등록요청 들어옴!");
		service.icmtWrite(vo);
		
		return "writeSuccess";	
	}
	
	@PostMapping("/jcmtWrite/{jobNo}")
	public String jcmtWrite(@RequestBody CommentVO vo) {
		System.out.println("댓글 등록요청 들어옴!");
		service.jcmtWrite(vo);
		
		return "writeSuccess";	
	}


	@GetMapping("/scmtList/{stuNo}")
	public List<CommentVO> scmtList(@PathVariable int stuNo, Model model){
		List<CommentVO> slist = service.scmtList(stuNo);
		System.out.println("댓글 개수: " + slist.size());
		
		
		
		return slist;
	}
	
	@GetMapping("/rcmtList/{resNo}")
	public List<CommentVO> rcmtList(@PathVariable int resNo, Model model){
		List<CommentVO> rlist = service.rcmtList(resNo);
		System.out.println("댓글 개수: " + rlist.size());
		
		
		return rlist;
	}
	
	@GetMapping("/icmtList/{interNo}")
	public List<CommentVO> icmtList(@PathVariable int interNo, Model model){
		List<CommentVO> ilist = service.icmtList(interNo);
		System.out.println("댓글 개수: " + ilist.size());
		
		return ilist;
	}
	
	@GetMapping("/fcmtList/{freeNo}")
	public List<CommentVO> fcmtList(@PathVariable int freeNo, Model model){
		List<CommentVO> flist = service.fcmtList(freeNo);
		System.out.println("댓글 개수: " + flist.size());

		
		return flist;
	}
	
	@GetMapping("/jcmtList/{jobNo}")
	public List<CommentVO> jcmtList(@PathVariable int jobNo){
		List<CommentVO> jlist = service.jcmtList(jobNo);
		System.out.println("댓글 개수: " + jlist.size());

		
		return jlist;
	}
	
	
	@PostMapping("/cmtDelete/{cmtNo}")
	public String cmtDelte(@PathVariable int cmtNo) {
		service.cmtDelete(cmtNo);
		
		return "cmtDelSuccess";
	}

	@PostMapping("/cmtUpdate")
	public String cmtUpdate(@RequestBody CommentVO vo) {
		
		service.cmtUpdate(vo);
		
		return "modSuccess";	
	}
	
	
	
}