package com.spring.blog.comment.service;

import java.util.List;

import com.spring.blog.command.CommentVO;

public interface ICommentService {

	// 댓글 등록
	void scmtWrite(CommentVO vo);
	void fcmtWrite(CommentVO vo);
	void rcmtWrite(CommentVO vo);
	void icmtWrite(CommentVO vo);
	void jcmtWrite(CommentVO vo);

	// 목록요청
	List<CommentVO> scmtList(int stuNo);
	List<CommentVO> fcmtList(int freeNo);
	List<CommentVO> rcmtList(int resNo);
	List<CommentVO> icmtList(int interNo);
	List<CommentVO> jcmtList(int jobNo);


	// 댓글 개수
	int scmtTotal(int stuNo);
	int fcmtTotal(int freeNo);
	int rcmtTotal(int resNo);
	int icmtTotal(int interNo);
	
	
	// 댓글 수정
	void cmtUpdate(CommentVO vo);

	// 댓글 삭제
	void cmtDelete(int cmtNo);
	
}
