package com.spring.blog.job.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.blog.command.CalendarVO;
import com.spring.blog.command.JobVO;
import com.spring.blog.job.mapper.IJobMapper;
import com.spring.blog.util.PageVO;

@Service
public class JobService implements IJobService{

	@Autowired
	private IJobMapper mapper;
	
	@Override
	public List<JobVO> getList(PageVO vo) {
		return mapper.getList(vo);
	}

	@Override
	public int getTotal(PageVO vo) {
		return mapper.getTotal(vo);
	}
	
	@Override
	public void regist(JobVO vo) {
		mapper.regist(vo);		
	}

	@Override
	public JobVO getDetail(int jobNo) {
		return mapper.getDetail(jobNo);
	}

	@Override
	public void update(JobVO vo) {
		mapper.update(vo);
	}

	@Override
	public void delete(int jobNo) {
		mapper.delete(jobNo);
	}

	@Override
	public void viewCount(int jobNo) {
		mapper.viewCount(jobNo);
	}

	@Override
	public List<CalendarVO> getCalendar() {
		return mapper.getCalendar();
	}


}
