package com.spring.blog.controller;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.spring.blog.command.CalendarVO;
import com.spring.blog.command.JobVO;
import com.spring.blog.job.service.IJobService;
import com.spring.blog.util.PageCreator;
import com.spring.blog.util.PageVO;

@Controller
@RequestMapping("/board/job")
public class JobController {
	
	@Autowired
	private IJobService service;
	
	@GetMapping("/jobList")
	public String joblist(PageVO vo, Model model) {
		
		PageCreator pc = new PageCreator();
		pc.setPaging(vo);
		pc.setArticleTotalCount(service.getTotal(vo));
		System.out.println(vo.toString());
		
		List<JobVO> jobList = service.getList(vo);
		
		model.addAttribute("jobList", jobList);
		model.addAttribute("pc", pc);
	
		
		return "board/job/jobList";
	}
	
	@GetMapping("/jobList2")
	   public String joblist2(PageVO vo, Model model) {
	      
	      PageCreator pc = new PageCreator();
	      pc.setPaging(vo);
	      pc.setArticleTotalCount(service.getTotal(vo));
	      System.out.println(vo.toString());
	      
	      List<JobVO> jobList = service.getList(vo);
	      
	      model.addAttribute("jobList", jobList);
	      model.addAttribute("pc", pc);
	   
	      
	      return "board/job/jobList2";
	   }
	
	
	@ResponseBody
	@RequestMapping(value = "/jobCalendar", method = RequestMethod.POST)
	public Map<String, Object> jobCalendar() {
		
		Map<String, Object> map = new HashMap<String, Object>(); 
		
		List<CalendarVO> calList = service.getCalendar();
		System.out.println(calList);
		
		map.put("calList", calList);
		System.out.println(map);
		
		return map;
		
	}
	
	@GetMapping("/jobWrite")
	public void jobRegist() {}
	
	@PostMapping("/jobRegist")
	public String jobRegist(JobVO vo, RedirectAttributes ra, @RequestParam("file") MultipartFile file) {
		
		String fileName = null;
		String fileRealName = null;
		String uploadPath = null;
				
		if(!file.isEmpty()) {
			fileRealName = file.getOriginalFilename();
			UUID uuid = UUID.randomUUID();
			String uuids = uuid.toString().replaceAll("-", "");
			String fileExtension = FilenameUtils.getExtension(fileRealName);
			uploadPath = "C:\\Users\\JyJung\\Desktop\\upload";
			
			System.out.println("저장할 폴더: " + uploadPath);
			System.out.println("실제 파일명: " + fileRealName);
			System.out.println("확장자: " + fileExtension);
			System.out.println("uuid: " + uuids);
			
			fileName = uuids + "." + fileExtension;
			System.out.println("변경해서 저장할 파일명: " + fileName);
			
			try {
				String fileLoca = uploadPath + "\\" + fileName;
				file.transferTo(new File(fileLoca));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
			
		vo.setFileName(fileName);
		vo.setFileRealName(fileRealName);
		vo.setUploadPath(uploadPath);
		
		service.regist(vo);
		ra.addFlashAttribute("msg","registSuccess");
		
		return "redirect:/board/job/jobList";
	}
	
	@GetMapping("/jobDetail")
	public void jobDetail(@RequestParam int jobNo, Model model, @ModelAttribute("p") PageVO vo) {
		service.viewCount(jobNo);
		
		model.addAttribute("job",service.getDetail(jobNo));
	}
	
	@GetMapping("/jobModify")
	public void jobModify(@RequestParam int jobNo, Model model, @ModelAttribute("p") PageVO vo) {
		System.out.println(service.getDetail(jobNo).toString());
		model.addAttribute("job", service.getDetail(jobNo));
	}
	
	@PostMapping("/jobUpdate")
	public String jobUpdate(JobVO vo, RedirectAttributes ra, @RequestParam("file") MultipartFile file,
							@RequestParam String fileRN, @RequestParam String fileN, @RequestParam String upload) {
		
		String fileName = fileN;
		String fileRealName = fileRN;
		String uploadPath = upload;	
		
		if(!file.isEmpty()) {
			fileRealName = file.getOriginalFilename();
			UUID uuid = UUID.randomUUID();
			String uuids = uuid.toString().replaceAll("-", "");
			String fileExtension = FilenameUtils.getExtension(fileRealName);
			uploadPath = "C:\\Users\\JyJung\\Desktop\\upload";
			
			System.out.println("저장할 폴더: " + uploadPath);
			System.out.println("실제 파일명: " + fileRealName);
			System.out.println("확장자: " + fileExtension);
			System.out.println("uuid: " + uuids);
			
			fileName = uuids + "." + fileExtension;
			System.out.println("변경해서 저장할 파일명: " + fileName);
			
			try {
				String fileLoca = uploadPath + "\\" + fileName;
				file.transferTo(new File(fileLoca));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
			
		vo.setFileName(fileName);
		vo.setFileRealName(fileRealName);
		vo.setUploadPath(uploadPath);
		
		service.update(vo);
		ra.addFlashAttribute("msg","updateSuccess");
	
		return "redirect:/board/job/jobDetail?jobNo="+vo.getJobNo();
	}

	@PostMapping("/jobDelete")
	public String jobDelete(JobVO vo, RedirectAttributes ra) {
		service.delete(vo.getJobNo());
		ra.addFlashAttribute("msg");
	
		return "redirect:/board/job/jobList";
	}
}
