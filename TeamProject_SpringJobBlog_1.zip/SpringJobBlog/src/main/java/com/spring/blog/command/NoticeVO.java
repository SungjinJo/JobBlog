package com.spring.blog.command;

import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/*
CREATE TABLE board_notice 
( 
    b_no     NUMBER(20) PRIMARY KEY,
    b_title  VARCHAR2(100) NOT NULL,
    b_regist_date date default SYSDATE, 
    b_content  VARCHAR2(50) NOT NULL,
    b_count NUMBER(20) NOT NULL
);
 */

@Getter
@Setter
@ToString
public class NoticeVO {
	
	private int boardNo;
	private String boardTitle;
	private String boardContent;
	private int boardCount;
	private Timestamp boardRegistDate;
	
}
