package com.spring.blog.notice.service;

import java.util.List;

import com.spring.blog.command.NoticeVO;

public interface INoticeService {
	
	
	void regist(NoticeVO vo);
	
	List<NoticeVO> getList();
	
	NoticeVO getContent(int b_no);
	
	void delete(int b_no);
	
	void update(NoticeVO vo);
	
	void hitcount(int b_no);

}
