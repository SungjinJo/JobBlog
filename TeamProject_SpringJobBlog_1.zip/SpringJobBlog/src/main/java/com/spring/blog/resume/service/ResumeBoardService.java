package com.spring.blog.resume.service;

import java.util.List; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.blog.command.ResumeBoardVO;
import com.spring.blog.resume.mapper.IResumeBoardMapper;
import com.spring.blog.util.PageVO;

@Service
public class ResumeBoardService implements IResumeBoardService {
	
	@Autowired
	private IResumeBoardMapper mapper;
	
	@Override
	public void write(ResumeBoardVO vo) {
		mapper.write(vo);
	}

			
	@Override
	public List<ResumeBoardVO> getList(PageVO vo) {
		List<ResumeBoardVO> list = mapper.getList(vo);

		return list;
	}

	@Override
	public int getTotal(PageVO vo) {
		return mapper.getTotal(vo);
	}

	@Override
	public ResumeBoardVO getDetail(int rNo) {
		mapper.updateViewCnt(rNo);
		return mapper.getDetail(rNo);
	}

	@Override
	public void update(ResumeBoardVO vo) {
		mapper.update(vo);
	}

	@Override
	public void delete(ResumeBoardVO vo) {
		mapper.delete(vo);
	}


	@Override
	public void download(ResumeBoardVO vo) {
		mapper.download(vo);
	}
	
	
}
