package com.spring.blog.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.spring.blog.command.InterviewBoardVO;
import com.spring.blog.command.UserVO;
import com.spring.blog.interview.service.IInterviewBoardService;
import com.spring.blog.user.service.IUserService;
import com.spring.blog.util.PageCreator;
import com.spring.blog.util.PageVO;

@Controller
@RequestMapping("/board/interview/")
public class InterviewBoardController {

	@Autowired
	private IInterviewBoardService service;
	
	@Autowired
	private IUserService uservice;

	//목록 화면
	@GetMapping("/interviewList")
	public String interviewList(PageVO vo, Model model) {
		
		PageCreator pc = new PageCreator();
		pc.setPaging(vo);
		pc.setArticleTotalCount(service.getTotal(vo));
		
		model.addAttribute("boardList", service.getList(vo));
		model.addAttribute("pc", pc);
			
		return "board/interview/interviewList";
	}
	
	//글쓰기 화면 처리
	@GetMapping("/interviewWrite")
	public void interviewWrite() {}

	//글 등록 처리
	@PostMapping("/interviewRegist")
	public String interviewRegist(InterviewBoardVO vo, RedirectAttributes ra, HttpSession session) {
		
		UserVO user = (UserVO) session.getAttribute("login");
		
		service.write(vo);
		uservice.boardCountAdd(user.getUserId());
		
		ra.addFlashAttribute("msg", "정상 등록 처리되었습니다.");
		
		return "redirect:/board/interview/interviewList"; 
		
	}
	
	//글 상세보기 처리
	@GetMapping("/interviewDetail")
	public void interviewDetail(@RequestParam int interNo, Model model, 
						   @ModelAttribute("p") PageVO vo) {
		model.addAttribute("article", service.getDetail(interNo));
	}

	//글 수정 페이지 이동
	@GetMapping("/interviewModify")
	public void interviewModify(@RequestParam int interNo, Model model) {
		model.addAttribute("article", service.getDetail(interNo));
	}
	
	//글 수정 처리
	@PostMapping("/interviewUpdate")
	public String interviewUpdate(InterviewBoardVO vo, RedirectAttributes ra) {
		service.update(vo);
		ra.addFlashAttribute("msg", "정상적으로 수정되었습니다.");
		
		return "redirect:/board/interview/interviewDetail?interNo=" + vo.getInterNo();
	}
	
	@PostMapping("/interviewDelete")
	public String freeDelete(InterviewBoardVO vo, RedirectAttributes ra) {
		service.delete(vo);
		System.out.println("게시글 삭제 요청");
		ra.addFlashAttribute("msg", "게시글이 정상 삭제되었습니다.");
		
		return "redirect:/board/interview/interviewList";
	}
	
}
