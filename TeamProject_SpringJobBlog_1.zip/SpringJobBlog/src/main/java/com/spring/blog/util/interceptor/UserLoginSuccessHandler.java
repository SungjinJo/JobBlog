package com.spring.blog.util.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.spring.blog.command.UserVO;

public class UserLoginSuccessHandler extends HandlerInterceptorAdapter {


	
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		
		System.out.println("로그인 인터셉터 동작!");
		
		ModelMap mv = modelAndView.getModelMap();
		UserVO vo = (UserVO) mv.get("user");
		System.out.println("interceptor vo: " + vo);
		
		if(vo != null) { //컨트롤러에서 로그인을 성공했던 사람
			System.out.println("로그인 성공 로직 동작!");
			//로그인 성공한 회원에게 세션 데이터를 생성해서 로그인 유지
			HttpSession session = request.getSession();
			session.setAttribute("login", vo);
			response.sendRedirect("/");
			
		} else {
			System.out.println("로그인 실패 로직 동작!");
			
			modelAndView.addObject("msg", "loginFail");
			modelAndView.setViewName("/user/userLogin");
		}

	}
	
}














