package com.spring.blog.util;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PasswordChangeVO {
	private String userId;
	private String userPw;
	private String userChangePw;
	private String userChangePwCheck;

}
