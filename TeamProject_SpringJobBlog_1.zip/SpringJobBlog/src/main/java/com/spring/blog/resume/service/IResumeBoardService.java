package com.spring.blog.resume.service;

import java.util.List; 

import com.spring.blog.command.ResumeBoardVO;
import com.spring.blog.util.PageVO;

public interface IResumeBoardService {

			//글 등록
			void write(ResumeBoardVO vo);
						
			//글 목록
			List<ResumeBoardVO> getList(PageVO vo);
			
			//총 게시물 수
			int getTotal(PageVO vo);
			
			//상세보기
			ResumeBoardVO getDetail(int rNo);
			
			//수정
			void update(ResumeBoardVO vo);

			//삭제
		    void delete(ResumeBoardVO vo);
			
		    //파일 다운로드
			void download(ResumeBoardVO vo);
			
			
			
}
