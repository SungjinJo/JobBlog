package com.spring.blog.command;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/*
CREATE TABLE job_table( -- 채용공고 테이블
    job_no NUMBER(10,0), --채용공고 번호
    job_title VARCHAR2(300) NOT NULL, --채용공고 제목
    job_writer VARCHAR2(50) NOT NULL, --채용공고 작성자
    job_detail VARCHAR2(2000) NOT NULL, --채용공고 내용
    job_schedule DATE, --채용공고 일정
    job_regdate DATE DEFAULT SYSDATE, --작성일
    job_updatedate DATE DEFAULT NULL, --수정일
    job_career VARCHAR2(50) NOT NULL, --경력
    job_jobtype VARCHAR2(50) NOT NULL, --직군
    job_companytype VARCHAR2(50) NOT NULL, --기업규모
    job_count NUMBER(10,0) DEFAULT 0, --조회수
    job_likecount NUMBER(10, 0) DEFAULT 0 --좋아요 카운트
);

ALTER TABLE job_table 
ADD CONSTRAINT job_table_pk PRIMARY KEY(job_no); --기본키 설정

CREATE SEQUENCE job_no_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 1000
    NOCYCLE
    NOCACHE;
    
CREATE TABLE job_attach_table(
    file_real_name VARCHAR2(100), --실제파일이름
    file_name VARCHAR2(100), --변경파일이름
    upload_path VARCHAR2(200), --파일경로
    job_no NUMBER(10,0) NOT NULL --글번호
);
*/

@Getter
@Setter
@ToString
public class JobVO {
	
	private int jobNo;
	private String jobTitle;
	private String jobWriter;
	private String jobDetail;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date jobSchedule;
	private Timestamp jobRegdate;
	private Timestamp jobUpdatedate;
	private String jobCareer;
	private String jobJobtype;
	private String jobCompanytype;
	private int jobCount;
	private int jobLikecount;
	//첨부파일
	private String fileRealName;
	private String fileName;
	private String uploadPath;

}
