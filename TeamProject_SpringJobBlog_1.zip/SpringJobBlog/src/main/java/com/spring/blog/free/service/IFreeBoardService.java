package com.spring.blog.free.service;

import java.util.List;

import com.spring.blog.command.FreeBoardVO;
import com.spring.blog.util.PageVO;

public interface IFreeBoardService {

	//글 등록
	void write(FreeBoardVO vo);
		
	//글 목록
	List<FreeBoardVO> getList(PageVO vo);
		
	//총 게시물 수
	int getTotal(PageVO vo);

	//상세보기
	FreeBoardVO getDetail(int freeNo);
		
	//수정
	void update(FreeBoardVO vo);

	//삭제
	void delete(FreeBoardVO vo);


}
