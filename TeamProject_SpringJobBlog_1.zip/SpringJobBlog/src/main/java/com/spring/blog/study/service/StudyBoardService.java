package com.spring.blog.study.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.blog.command.ResumeBoardVO;
import com.spring.blog.command.StudyBoardVO;
import com.spring.blog.study.mapper.IStudyBoardMapper;
import com.spring.blog.util.PageVO;

@Service
public class StudyBoardService implements IStudyBoardService {

	@Autowired
	private IStudyBoardMapper mapper;
	
	@Override
	public void write(StudyBoardVO vo) {
		mapper.write(vo);
	}

	@Override
	public List<StudyBoardVO> getList(PageVO vo) {
		List<StudyBoardVO> list = mapper.getList(vo);
		return list;
	}

	@Override
	public int getTotal(PageVO vo) {
		return mapper.getTotal(vo);
	}


	@Override
	public StudyBoardVO getDetail(int stuNo) {
		mapper.updateViewCnt(stuNo);
		return mapper.getDetail(stuNo);
	}

	@Override
	public void update(StudyBoardVO vo) {
		mapper.update(vo);
	}

	@Override
	public void delete(StudyBoardVO vo) {
		mapper.delete(vo);
	}

	
}
