package com.spring.blog.user.service;

import com.spring.blog.command.UserVO;
import com.spring.blog.util.PasswordChangeVO;

public interface IUserService {
	
	//유저등업
	void userGradeUpdate(UserVO vo);
	
	//개인 회원가입
	public void generalJoin(UserVO user);
	
	//기업 회원가입 
	public void companyJoin(UserVO user);
	
	//아이디 중복체크
	public int idCheck(String userId);
	
	//로그인
	UserVO login(String userId, String userPw);	
    
	//회원 정보 얻어오기
	UserVO getInfo(String userId);
	
	//회원 정보 수정
	void updateUser(UserVO user);
	
	//비밀번호 수정
	void pwUser(UserVO user);
	
	//회원탈퇴
	void deleteUser(UserVO user);
	
	//비밀번호 체크
	int checkPw(UserVO user);
	
	//비밀번호 변경체크2
    int checkPw2(PasswordChangeVO vo);
    
  //비밀번호 변경
    void changeUserPassword(PasswordChangeVO vo);
    
    //게시물 수 가져오기
    int getBoardCount(String userId);
    
    //게시물 카운트 업데이트
    void boardCountAdd(String userId);


}
