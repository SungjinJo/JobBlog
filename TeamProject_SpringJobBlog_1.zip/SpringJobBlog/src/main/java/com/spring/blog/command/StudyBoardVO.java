package com.spring.blog.command;

import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/*
--스터디 게시판
CREATE TABLE study_board( 
    s_no NUMBER(10, 0), --글번호 (pk)
    s_title VARCHAR2(300) NOT NULL, --글제목
    s_writer VARCHAR2(50) NOT NULL, --작성자 fk (닉네임)
    s_detail VARCHAR2(2000) NOT NULL, --글내용
    s_regdate DATE DEFAULT SYSDATE, -- 작성일
    s_updatedate DATE DEFAULT NULL, -- 수정일
    s_area VARCHAR2(50),--지역 
    s_count NUMBER(10, 0),  --조회수
    s_likeCount NUMBER(10, 0) --좋아요 카운트
);

ALTER TABLE study_board
ADD CONSTRAINT study_board_pk PRIMARY KEY(s_no);

CREATE SEQUENCE s_no_seq --글번호 시퀀스
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 10000
    NOCYCLE
    NOCACHE;
 */

@Getter
@Setter
@ToString
public class StudyBoardVO {

	private int stuNo;
	private String stuTitle;
	private String stuWriter;
	private String stuDetail;
	private Timestamp stuRegdate;
	private Timestamp stuUpdatedate;
	private String stuArea;
	private int stuCount;
	private int stuLikeCount;


}
