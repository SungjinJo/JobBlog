package com.spring.blog.free.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.blog.command.FreeBoardVO;
import com.spring.blog.free.mapper.IFreeBoardMapper;
import com.spring.blog.util.PageVO;

@Service
public class FreeBoardService implements IFreeBoardService {

	@Autowired
	private IFreeBoardMapper mapper;
	
	@Override
	public void write(FreeBoardVO vo) {
		mapper.write(vo);
	}

	@Override
	public List<FreeBoardVO> getList(PageVO vo) {
		List<FreeBoardVO> list = mapper.getList(vo);
		return list;
	}

	@Override
	public int getTotal(PageVO vo) {
		return mapper.getTotal(vo);
	}

	@Override
	public FreeBoardVO getDetail(int freeNo) {
		mapper.updateViewCnt(freeNo);
		return mapper.getDetail(freeNo);
	}

	@Override
	public void update(FreeBoardVO vo) {
		mapper.update(vo);
	}

	@Override
	public void delete(FreeBoardVO vo) {
		mapper.delete(vo);
	}


	
}
