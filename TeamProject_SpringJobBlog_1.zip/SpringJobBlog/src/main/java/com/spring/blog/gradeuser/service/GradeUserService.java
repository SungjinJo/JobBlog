package com.spring.blog.gradeuser.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.blog.gradeuser.mapper.IGradeUserMapper;
import com.spring.blog.command.GradeUserVO;
import com.spring.blog.util.PageVO;


@Service
public class GradeUserService implements IGradeUserService{
	
	private IGradeUserMapper mapper;
	
	@Autowired
	public GradeUserService(IGradeUserMapper mapper) {
		this.mapper = mapper;
	}

	@Override
	public void regist(GradeUserVO vo) {
		mapper.regist(vo);
		
	}

	@Override
	public List<GradeUserVO> getList(PageVO vo) {
		List<GradeUserVO> list = mapper.getList(vo);		
		return list;		
	}

	@Override
	public GradeUserVO getContent(int userNo) {
	  
		return mapper.getContent(userNo);
	}

	@Override
	public void delete(int userNo) {
		mapper.delete(userNo);
		
	}

	@Override
	public int getTotal(PageVO vo) {
	   return mapper.getTotal(vo);
	}

	@Override
	public void gradeApplyAccess(String userGrade, String userId) {
		System.out.println("서비스객체" + userGrade);
		mapper.gradeApplyAccess(userGrade, userId);
		
	}

	@Override
	public void gradeApplyCheck(int userNo) {
		mapper.gradeApplyCheck(userNo);
		
		
	}

}
